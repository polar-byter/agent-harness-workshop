# Подсказки к текущему заданию

- `workspace.py` -> `preview_change`

Мы хотим увидеть предложение до записи файла. Поэтому читаем старый текст, сравниваем его с `new_text` и возвращаем описание изменения. Формирование diff - готовая возможность стандартной библиотеки; в этом упражнении не нужно придумывать алгоритм сравнения строк.

В файле текущего задания уже есть начало функции. Допишите её по заготовке ниже: `...` обозначает место для вашего выражения, а не готовую команду. Когда заполните пропуски, удалите строку `raise NotImplementedError(...)` из каркаса. Заголовок `def` в файле уже есть - вторую функцию с тем же именем создавать не нужно.

```python
def preview_change(root: Path, relative: str, new_text: str) -> dict:
    path = workspace_path(root, relative)
    old_text = path.read_text(encoding='utf-8')
    lines = difflib.unified_diff(
        old_text.splitlines(keepends=True),
        new_text.splitlines(keepends=True),
        fromfile='before/' + relative,
        tofile='after/' + relative,
    )
    before_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    return {
        'path': relative,
        'before_hash': before_hash,
        'new_text': ...,
        'diff': ...,
    }
```

В поле `new_text` положите переданный параметр `new_text`. В поле `diff` - `"".join(lines)`: библиотека отдаёт строки сравнения по одной, а нам нужен единый текст. Пустая строка перед `.join` означает, что дополнительных разделителей не добавляем - переводы уже сохранены через `keepends=True`.

`fromfile` и `tofile` задают подписи старого и нового вариантов в diff; это не команды записи файлов. Цепочка `sha256(...).hexdigest()` вычисляет контрольную строку по исходным байтам. Готовую строку сохраним в `before_hash`, чтобы следующий урок мог заметить изменение исходника. До конца этой функции ничего не записываем на диск.
